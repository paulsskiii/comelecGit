package com.learning.smartwallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartwalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartwalletApplication.class, args);
	}

}
